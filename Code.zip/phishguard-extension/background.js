chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analyze") {
        analyzeUrl(request.url)
            .then(data => sendResponse(data))
            .catch(error => {
                console.error("Error analyzing URL:", error);
                sendResponse({ error: error.message });
            });
        return true; // Indicates we will send a response asynchronously
    }
});

async function analyzeUrl(url) {
    try {
        const response = await fetch("http://localhost:8000/analyze", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ url: url })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Save latest analysis result to storage for the popup
        await chrome.storage.local.set({ latestAnalysis: data });

        return data;
    } catch (error) {
        console.error("Error connecting to backend:", error);
        throw error;
    }
}
