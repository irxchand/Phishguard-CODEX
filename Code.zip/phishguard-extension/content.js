const checkedLinks = new Map();

// Check URLs on hover
document.addEventListener('mouseover', async (e) => {
  const link = e.target.closest('a');
  if (!link || !link.href) return;

  const url = link.href;

  // We only want to analyze real HTTP/HTTPS links, ignore javascript:void(0) or empty anchors
  if (!url.startsWith('http')) return;

  // If we already know the status, apply it immediately when hovering
  if (checkedLinks.has(url)) {
    const result = checkedLinks.get(url);
    if (result && result !== 'pending' && result.final_score !== undefined) {
      if (result.final_score >= 0.7) {
        link.title = `WARNING: PhishGuard flagged this as Unsafe! (${(result.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid red", "important");
        link.style.setProperty("background-color", "rgba(255,0,0,0.2)", "important");
      } else if (result.final_score >= 0.4) {
        link.title = `Notice: PhishGuard flagged this as Suspicious (${(result.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid orange", "important");
        link.style.setProperty("background-color", "rgba(255,165,0,0.2)", "important");
      } else {
        link.title = `Safe: PhishGuard flagged this as Safe (${(result.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid #4CAF50", "important");
        link.style.setProperty("background-color", "rgba(76,175,80,0.2)", "important");
      }
    }
    return;
  }

  // Mark as pending
  checkedLinks.set(url, 'pending');

  try {
    const response = await chrome.runtime.sendMessage({ action: "analyze", url: url });

    if (response && response.final_score !== undefined) {
      checkedLinks.set(url, response);

      // Optional: Visual indicator on hover
      if (response.final_score >= 0.7) {
        link.title = `WARNING: PhishGuard flagged this as Unsafe! (${(response.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid red", "important");
        link.style.setProperty("background-color", "rgba(255,0,0,0.2)", "important");
      } else if (response.final_score >= 0.4) {
        link.title = `Notice: PhishGuard flagged this as Suspicious (${(response.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid orange", "important");
        link.style.setProperty("background-color", "rgba(255,165,0,0.2)", "important");
      } else {
        link.title = `Safe: PhishGuard flagged this as Safe (${(response.final_score * 100).toFixed(1)}%)`;
        link.style.setProperty("outline", "4px solid #4CAF50", "important");
        link.style.setProperty("background-color", "rgba(76,175,80,0.2)", "important");
      }
    } else {
      checkedLinks.delete(url); // Remove so we can try again
    }
  } catch (error) {
    console.error("PhishGuard hover check failed", error);
    checkedLinks.delete(url);
  }
});

// Handle click
document.addEventListener('click', async (e) => {
  const link = e.target.closest('a');
  if (!link || !link.href) return;

  if (!link.href.startsWith('http')) return;

  const url = link.href;

  const result = checkedLinks.get(url);

  // If we already know it's bad, block immediately but ask for confirmation
  if (result && result !== 'pending') {
    if (result.final_score >= 0.7) {
      e.preventDefault();
      e.stopPropagation(); // Stop other dialogs from opening
      const proceed = confirm(`PhishGuard Alert!\n\nThis link appears unsafe.\nRisk Score: ${(result.final_score * 100).toFixed(1)}%\n\nDo you want to proceed anyway?`);
      if (proceed) {
        window.location.href = url;
      }
      return;
    }
    // Else it's safe to proceed normally
    return;
  }

  // If we haven't checked or it's still pending, block, check and redirect
  e.preventDefault();
  e.stopPropagation(); // Prevent the click from triggering page dialogs while checking

  try {
    const response = await chrome.runtime.sendMessage({ action: "analyze", url: url });
    checkedLinks.set(url, response); // Cache it too

    if (response && response.final_score !== undefined) {
      if (response.final_score < 0.7) {
        window.location.href = url;
      } else {
        const proceed = confirm(`PhishGuard Alert!\n\nThis link appears unsafe.\nRisk Score: ${(response.final_score * 100).toFixed(1)}%\n\nDo you want to proceed anyway?`);
        if (proceed) {
          window.location.href = url;
        }
      }
    } else {
      window.location.href = url;
    }
  } catch (error) {
    console.error("Error communicating with PhishGuard background script", error);
    window.location.href = url;
  }
}, { capture: true }); // Use capture: true to run before the website's own scripts (e.g. dialogs)
