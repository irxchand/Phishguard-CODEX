document.addEventListener('DOMContentLoaded', async () => {
    const statusText = document.getElementById('status-text');
    const scoreText = document.getElementById('score-text');
    const scoreFill = document.getElementById('score-fill');
    const explainBtn = document.getElementById('explain-btn');
    const explanationArea = document.getElementById('explanation-area');
    const explanationText = document.getElementById('explanation-text');

    // Fetch the latest analysis result
    chrome.storage.local.get(['latestAnalysis'], (result) => {
        const data = result.latestAnalysis;

        if (data) {
            // Update status
            statusText.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);

            // Update color based on status
            if (data.status === 'safe') {
                statusText.style.color = '#4CAF50';
            } else if (data.status === 'suspicious') {
                statusText.style.color = '#FFC107';
            } else if (data.status === 'unsafe') {
                statusText.style.color = '#F44336';
            }

            // Update score bar
            const scorePercent = (data.final_score * 100).toFixed(1);
            scoreText.textContent = `${scorePercent}%`;
            scoreFill.style.width = `${scorePercent}%`;

            if (data.final_score >= 0.7) {
                scoreFill.style.backgroundColor = '#F44336';
            } else if (data.final_score >= 0.4) {
                scoreFill.style.backgroundColor = '#FFC107';
            } else {
                scoreFill.style.backgroundColor = '#4CAF50';
            }

            // Show explain button if explanation is available
            if (data.explanation) {
                explainBtn.style.display = 'block';

                explainBtn.addEventListener('click', () => {
                    explanationText.textContent = data.explanation;
                    explanationArea.style.display = 'block';
                    explainBtn.style.display = 'none';
                });
            }
        } else {
            statusText.textContent = "No recent activity";
        }
    });
});
