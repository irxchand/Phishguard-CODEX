import dns.resolver
import concurrent.futures
from datetime import datetime
from urllib.parse import urlparse

def extract_ssl_features(url: str) -> dict:
    """
    Extracts SSL/domain features from a URL.
    Returns a dictionary of features:
    ['domain_registration_length', 'domain_age', 'dns_record', 'whois_registered_domain', 'https_token']
    """
    if not url.startswith("http"):
        full_url = "http://" + url
    else:
        full_url = url
        
    parsed = urlparse(full_url)
    hostname = parsed.hostname or ""
    
    # https_token
    https_token = 1 if parsed.scheme == "https" else 0
    
    # Neutral defaults (0 means safe/neutral, 1 means suspicious)
    # The prompt explicitly asks to stop penalizing legitimate domains on lookup failures
    domain_registration_length = 0    
    domain_age = 0                    
    dns_record = 0                    
    whois_registered_domain = 0       
    
    # 1. DNS Record
    try:
        resolver = dns.resolver.Resolver()
        resolver.lifetime = 3.0  # 3 seconds timeout
        resolver.resolve(hostname, 'A')
        dns_record = 0 # found
    except Exception:
        dns_record = 0 # not found, but neutral score rather than 1
        
    # 2. Whois details 
    # Use ThreadPoolExecutor to enforce a strict 3-second timeout as whois library blocks
    def fetch_whois():
        import whois
        return whois.whois(hostname)

    w = None
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(fetch_whois)
            w = future.result(timeout=3.0)
    except Exception:
        pass # timeout or error, keep neutral defaults

    if w:
        try:
            if w.domain_name:
                whois_registered_domain = 0
                
                # Domain Age
                creation_date = w.creation_date
                if type(creation_date) is list:
                    creation_date = creation_date[0]
                if creation_date:
                    age_delta = datetime.now() - creation_date
                    domain_age = age_delta.days
                    
                # Domain Registration Length
                expiration_date = w.expiration_date
                if type(expiration_date) is list:
                    expiration_date = expiration_date[0]
                if expiration_date:
                    length_delta = expiration_date - datetime.now()
                    domain_registration_length = length_delta.days
        except Exception:
            pass # keep defaults
        
    return {
        "domain_registration_length": domain_registration_length,
        "domain_age": domain_age,
        "dns_record": dns_record,
        "whois_registered_domain": whois_registered_domain,
        "https_token": https_token
    }
