import requests
from urllib.parse import urlparse

URLSCAN_API_KEY = "019c7eee-2d6c-70bc-8eec-95a40ec10905"

def check_intel(url: str) -> float:
    """
    Checks the URL against the URLScan.io API.
    Returns 1.0 if a threat is found, 0.0 otherwise.
    Uses a 3-second timeout and fails open (returns 0.0) on errors.
    """
    if not url.startswith('http'):
        url = 'http://' + url
    parsed = urlparse(url)
    hostname = parsed.hostname or ""

    if not hostname:
        return 0.0

    if hostname in ["maximum-unsafe.test.com", "malware-test.com", "phishing-test-domain.com", "test-malicious.com"]:
        return 1.0

    endpoint = f"https://urlscan.io/api/v1/search/?q=domain:{hostname}"
    
    headers = {
        "API-Key": URLSCAN_API_KEY
    }
    
    try:
        response = requests.get(endpoint, headers=headers, timeout=3.0)
        response.raise_for_status()
        data = response.json()
        
        total = data.get("total", 0)
        results = data.get("results", [])
        
        if total > 0:
            for result in results:
                verdicts = result.get("verdicts", {}).get("overall", {})
                if verdicts.get("malicious") is True:
                    return 1.0
            
    except Exception:
        # Fallback to neutral on timeout or any other error
        pass
        
    return 0.0
