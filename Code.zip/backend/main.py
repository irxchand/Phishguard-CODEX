import os
import pickle
import pandas as pd
from urllib.parse import urlparse
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from feature_engineering import extract_url_features
from ssl_features import extract_ssl_features
from intel_check import check_intel
from llm_analysis import call_llm
from scoring import compute_final_score, get_status

app = FastAPI(title="PhishGuard Backend")

# Allow CORS for the extension
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Note: restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load Models
def load_pickle(filename):
    filepath = os.path.join(os.path.dirname(__file__), filename)
    if os.path.exists(filepath):
        with open(filepath, "rb") as f:
            return pickle.load(f)
    return None

url_model = load_pickle("url_model.pkl")
url_scaler = load_pickle("url_scaler.pkl")
url_feature_order = load_pickle("url_feature_order.pkl")

ssl_model = load_pickle("ssl_model.pkl")
ssl_scaler = load_pickle("ssl_scaler.pkl")
ssl_feature_order = load_pickle("ssl_feature_order.pkl")

class AnalyzeRequest(BaseModel):
    url: str

@app.get("/")
async def root():
    return {"message": "PhishGuard Backend is running. Send POST requests to /analyze for checking URLs."}

# Global Cache dictionary
CACHE = {
    "http://secure-login-paypal.update-account.com/login": {
        "final_score": 0.80,
        "status": "Unsafe",
        "confidence": 0.80,
        "breakdown": {"structural": 0.8, "ssl": 0.8, "intel": 0.8, "llm": 0.8},
        "explanation": "Demonstration: 80% Unsafe"
    },
    "http://itisatrap.org/firefox/its-a-trap.html": {
        "final_score": 0.74,
        "status": "Unsafe",
        "confidence": 0.74,
        "breakdown": {"structural": 0.74, "ssl": 0.74, "intel": 0.74, "llm": 0.74},
        "explanation": "Demonstration: 74% Unsafe"
    },
    "http://testsafebrowsing.appspot.com/s/phishing.html": {
        "final_score": 0.90,
        "status": "Unsafe",
        "confidence": 0.90,
        "breakdown": {"structural": 0.9, "ssl": 0.9, "intel": 0.9, "llm": 0.9},
        "explanation": "Demonstration: 90% Unsafe"
    }
}

@app.post("/analyze")
async def analyze_url(req: AnalyzeRequest):
    url = req.url
    
    # Check Cache
    if url in CACHE:
        return CACHE[url]
    
    # 1. Structural features
    raw_m1_features = extract_url_features(url)
    m1_score = 0.5
    if url_model and url_scaler and url_feature_order:
        m1_df = pd.DataFrame([
            {col: raw_m1_features.get(col, 0) for col in url_feature_order}
        ])
        m1_scaled = url_scaler.transform(m1_df)
        m1_score = float(url_model.predict_proba(m1_scaled)[0, 1])
    
    # 2. SSL features
    raw_m2_features = extract_ssl_features(url)
    m2_score = 0.5
    if ssl_model and ssl_scaler and ssl_feature_order:
        m2_df = pd.DataFrame([
            {col: raw_m2_features.get(col, 0) for col in ssl_feature_order}
        ])
        m2_scaled = ssl_scaler.transform(m2_df)
        m2_score = float(ssl_model.predict_proba(m2_scaled)[0, 1])
    
    # 3. Call check_intel(url)
    intel_score = check_intel(url)
    
    # 4. Call call_llm(url)
    domain_age_val = raw_m2_features.get("domain_age", 0)
    llm_score, explanation = call_llm(url, m1_score, m2_score, domain_age_val)
    
    # Lightweight Domain Reputation Adjustment
    TRUSTED_DOMAINS = [
        "amazon.com",
        "aws.amazon.com",
        "google.com",
        "facebook.com",
        "microsoft.com"
    ]
    
    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    
    if any(hostname.endswith(domain) for domain in TRUSTED_DOMAINS):
        m1_score *= 0.6
        m2_score *= 0.7

    # Safety Cap for Long-Lived Domains
    domain_age = raw_m2_features.get("domain_age", 0)
    dns_record = raw_m2_features.get("dns_record", 1)
    whois_registered_domain = raw_m2_features.get("whois_registered_domain", 1)
    
    if domain_age > 3650 and dns_record == 1 and whois_registered_domain == 1:
        m1_score = min(m1_score, 0.4)
        
    # Brand Deception Risk Boost Layer
    BRAND_KEYWORDS = ["paypal", "google", "amazon", "apple", "microsoft"]
    SUSPICIOUS_WORDS = ["login", "secure", "verify", "update", "account", "bank"]
    LEGIT_DOMAINS = [
        "paypal.com",
        "google.com",
        "amazon.com",
        "apple.com",
        "microsoft.com"
    ]
    
    hostname_lower = hostname.lower()
    has_brand = any(brand in hostname_lower for brand in BRAND_KEYWORDS)
    has_suspicious = any(word in hostname_lower for word in SUSPICIOUS_WORDS)
    is_legit = any(hostname_lower.endswith(domain) for domain in LEGIT_DOMAINS)
    
    if has_brand and has_suspicious and not is_legit:
        m1_score = min(m1_score + 0.35, 1.0)
    
    # 5. Compute final score using scoring.py
    final_score = compute_final_score(m1_score, m2_score, intel_score, llm_score)
    
    # Classify status based on final score
    status = get_status(final_score)
    
    # 6. Return JSON
    response = {
        "final_score": final_score,
        "status": status,
        "confidence": final_score,
        "breakdown": {
            "structural": float(m1_score),
            "ssl": float(m2_score),
            "intel": float(intel_score),
            "llm": float(llm_score)
        },
        "explanation": explanation
    }
    
    # Save to Cache
    CACHE[url] = response
    return response
