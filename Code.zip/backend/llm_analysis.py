import requests
import json
from typing import Tuple

GROQ_API_KEY = "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"

def call_llm(url: str, m1: float = 0.5, m2: float = 0.5, domain_age: int = 0) -> Tuple[float, str]:
    """
    Calls Groq Chat Completion API to analyze phishing likelihood.
    Returns a Tuple (confidence: float, reason: str).
    Uses a 5-second timeout and fails open (0.1, 'LLM unavailable') on errors.
    """
    endpoint = "https://api.groq.com/openai/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    prompt = f"You are a cybersecurity model. Analyze phishing likelihood.\n\nURL: {url}\nStructural score: {m1}\nSSL score: {m2}\nDomain age: {domain_age}\n\nReturn ONLY valid JSON:\n{{\n \"confidence\": float between 0 and 1,\n \"reason\": short explanation\n}}"

    payload = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0,
        "max_tokens": 200
    }
    
    try:
        response = requests.post(endpoint, json=payload, headers=headers, timeout=5.0)
        response.raise_for_status()
        
        data = response.json()
        content = data["choices"][0]["message"]["content"]
        
        result = json.loads(content)
        
        confidence = float(result.get("confidence", 0.1))
        reason = str(result.get("reason", "No reason provided."))
        
        return confidence, reason
        
    except Exception:
        # Fallback to neutral on timeout or any other error
        return 0.1, "LLM unavailable"
