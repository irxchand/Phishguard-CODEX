import requests
import json

def get_malicious_urls():
    url = "https://urlscan.io/api/v1/search/?q=verdicts.malicious:true"
    headers = {"API-Key": "019c7eee-2d6c-70bc-8eec-95a40ec10905"}
    
    response = requests.get(url, headers=headers)
    data = response.json()
    
    results = data.get("results", [])
    urls = []
    
    for r in results:
        task = r.get("task", {})
        u = task.get("url")
        if u and u not in urls:
            urls.append(u)
        if len(urls) >= 5:
            break
            
    print("Found malicious URLs:")
    for u in urls:
        print(u)
        
if __name__ == "__main__":
    get_malicious_urls()
