import re
from urllib.parse import urlparse

def extract_url_features(url: str) -> dict:
    """
    Extracts structural features from a URL.
    Returns a dictionary of features:
    ['length_url', 'length_hostname', 'nb_dots', 'nb_hyphens', 'nb_slash', 'nb_www', 'ip']
    """
    if not url.startswith("http"):
        full_url = "http://" + url
    else:
        full_url = url
        
    parsed = urlparse(full_url)
    hostname = parsed.hostname or ""
    
    # 1. length_url
    length_url = len(url)
    
    # 2. length_hostname
    length_hostname = len(hostname)
    
    # 3. nb_dots
    nb_dots = url.count('.')
    
    # 4. nb_hyphens
    nb_hyphens = url.count('-')
    
    # 5. nb_slash
    nb_slash = url.count('/')
    
    # 6. nb_www
    nb_www = url.lower().count('www')
    
    # 7. ip
    ip_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    ip = 1 if ip_pattern.match(hostname) else 0
    
    return {
        "length_url": length_url,
        "length_hostname": length_hostname,
        "nb_dots": nb_dots,
        "nb_hyphens": nb_hyphens,
        "nb_slash": nb_slash,
        "nb_www": nb_www,
        "ip": ip
    }
