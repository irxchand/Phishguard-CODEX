def compute_final_score(m1: float, m2: float, intel: float, llm: float) -> float:
    """
    Computes a weighted final score based on model outputs.
    Weights: 
    0.35 * m1 + 0.15 * m2 + 0.4 * intel + 0.1 * llm
    """
    if intel == 1.0:
        return 1.0
        
    return (0.35 * m1) + (0.15 * m2) + (0.5 * intel) + (0 * llm)

def get_status(final_score: float) -> str:
    """
    Classifies the status based on the final score.
    Returns 'Safe' (0-0.30), 'Suspicious' (>0.30-0.65), or 'Unsafe' (>0.65).
    """
    if final_score > 0.65:
        return "Unsafe"
    elif final_score > 0.30:
        return "Suspicious"
    else:
        return "Safe"
